# UInjectForge 1.1.0 App Review fixtures

These generated inputs exercise local import, building and Files export on
iPhone or iPad. They contain no playable games, emulator or game assets.
Use Loadiine output for this packaging check. The result is non-playable and
does not need a Wii U.

1. Open this ZIP in Files to extract it, and keep the extracted folder available
   in On My iPhone or On My iPad. The NES and SNES folders each contain a Base
   folder and a matching eight-byte source marker.
2. In UInjectForge, dismiss the tutorial and select NES or SNES. In Step 1,
   tap Use Local Base, browse to the matching Base folder, and tap Open.
   Choose the folder that shows code, content and meta. The app reads the
   generated base name and matching title ID from the metadata.
3. In Step 2, select the matching Synthetic NES.nes or Synthetic SNES.sfc
   file from Files and enter a title name such as Synthetic Test.
4. Open Step 4, choose Loadiine, and tap Build. A successful build uses one
   of the three free builds. Use Export Latest Build to save the result through
   Files.

No account, network download, retail key or purchase is needed for this check.
